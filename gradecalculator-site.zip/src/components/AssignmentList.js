import React from "react";

const CourseList = ({ courses, onDeleteCourse, calculateGPA }) => {
  return (
    <div className="section2">
      <div>
        <h2>Course List</h2>
        <u1 style={index}>
          <li>Course</li>
          <li>Credits</li>
          <li>Grade</li>
          <li>Action</li>
        </u1>
        {courses.map((course, index) => (
          <u1 key={index}>
            <li>{course.courseName}</li>
            <li>{course.creditHours}</li>
            <li>{course.grade}</li>
            <li>
              <button onClick={() => onDeleteCourse(index)}>Delete</button>
            </li>
          </u1>
        ))}
      </div>
      <div>
        <h3>GPA: {calculateGPA().toFixed(2)}</h3>
      </div>
    </div>
  );
};

export default CourseList;
